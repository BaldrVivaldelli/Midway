import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('.');
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), 'utf8');

test('release workflow configura attestation, updater json y checksums', () => {
  const workflow = read('.github/workflows/release.yml');
  assert.match(workflow, /actions\/attest@v4/);
  assert.match(workflow, /generate-updater-json\.mjs/);
  assert.match(workflow, /generate-checksums\.mjs/);
  assert.match(workflow, /releaseAssetNamePattern/);
});

test('tauri release configs existen y separan stable de beta', () => {
  const releaseConfig = read('src-tauri/tauri.release.conf.json');
  const betaConfig = read('src-tauri/tauri.beta.conf.json');
  assert.match(releaseConfig, /createUpdaterArtifacts/);
  assert.match(releaseConfig, /latest\.json/);
  assert.match(betaConfig, /latest-beta\.json/);
});

test('documentación de distribución enumera secrets y canales', () => {
  const docs = read('docs/distribution.md');
  assert.match(docs, /TAURI_SIGNING_PRIVATE_KEY/);
  assert.match(docs, /APPLE_CERTIFICATE/);
  assert.match(docs, /latest-beta\.json/);
});
